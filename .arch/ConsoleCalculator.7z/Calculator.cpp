#include <stdexcept>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <memory>

#include "Calculator.h"

constexpr int MAXFOLLOWEDBY = 10;
constexpr int MAXOPERANDCOUNT = 50;
constexpr double TooSmallNumber = 10E-20;


using namespace std;



class NodeType
{
protected:
    Priority priority;
    unsigned int followedbycount = 0;
    ParserName followedby[MAXFOLLOWEDBY];
    string symbolset;
    int len;
public:
    NodeType(string symbolset, int len) {
        this->len = len;
        this->symbolset = symbolset;
        this->followedbycount = 0;
    }
    //конструктор копии
//            NodeType(const NodeType &original) {
//                this->name = original.name;
//                this->followedby= new string[maxfollowedby];
//  //...add copy foollowed by?
//                this->len = original.len;
//                this->symbolset=original.symbolset;
//            }
    virtual ~NodeType() {
    };
    Priority getpriority() { return priority; };
    virtual ParserName name() { return ParserName::NodeType; };
    virtual bool CanBeFollowedBy(ParserName name) {
        for (unsigned int i = 0; i < followedbycount; i++) {
            //.find и другие методы возвращаюют тип string::size_type
            if (followedby[i] == name) return true;
        }
        return false;
    }
    string getsymbolset() { return symbolset; };
    //функция "Am I?" возвращает
    // -1 если строка-параметр не может быть объектом этого типа
    // позицию в строке которвая явл-ся следующей за последней позицией подстроки которая явл-ся данным класом
    // Number.Ami("12+23") вернет 3
    virtual int CanIStartWith(string substr)
    {
        if (len == 0) {
            string::size_type i = 0;
            while (i <= substr.size() - 1) {
                if (symbolset.find(substr[i]) == string::npos)  break;
                i++;
            }
            return i - 1;
        }
        else if (len == 1)
        {
            if (symbolset.find(substr[0]) == string::npos)
                return -1;
            else
                return 0;
        }

        return -1;  //error
    }
    //
    virtual double Exec(const double operand[], int operandcount, string str) { return 0.0; };
};



class Number : public NodeType
{
public:
    Number() : NodeType(".0123456789", 0)
    {
        priority = Priority::Undefined;
        followedby[0] = ParserName::BinaryOperation;
        followedby[1] = ParserName::OperandDelimiter;
        followedby[2] = ParserName::CompoundEnd;
        followedbycount = 3;
    };
    ParserName name() { return ParserName::Number; };
    double Exec(const double operand[], int operandcount, string str)
    {
        return stof(str);   //из строки в double
    }
};

    class Constant: public NodeType
    {
    public:
        Constant(string symbols) : NodeType(symbols, 0)
        {   priority=Priority::Undefined;
            followedby[0] = ParserName::BinaryOperation;
            followedby[1] = ParserName::OperandDelimiter;
            followedby[2] = ParserName::CompoundEnd;
            followedbycount =3;
        };
        ParserName name() { return ParserName::Number; };
        virtual int CanIStartWith(string str)
        {
            if (str.find(symbolset) == 0)
                return symbolset.length()-1;
            else
                return -1;
        }
        double Exec(const double operand[], int operandcount, string str) { return 0.0;}
    };

    class BinaryOperation : public NodeType {
    public:
        BinaryOperation(string sign, Priority priority ): NodeType (sign, 1 ) {
            this->priority=priority;
            this->symbolset=sign;
            followedby[0] = ParserName::Number;
            followedby[1] = ParserName::CompoundStart;
            followedby[2] = ParserName::UnaryOperation;
            followedbycount =3;
        }
        ParserName name() { return ParserName::BinaryOperation; } ;
    };

    class UnaryOperation : public NodeType {
    public:
        UnaryOperation (string symbolset, Priority priority ): NodeType(symbolset, 1) {
            this->priority=priority;
            followedby[0] = ParserName::Number;
            followedby[1] = ParserName::CompoundStart;
            followedby[2] = ParserName::CompoundEnd;
            followedby[3] = ParserName::BinaryOperation;
            followedby[4] = ParserName::UnaryOperation;
            followedbycount =5;
         };
        ParserName name() { return ParserName::UnaryOperation; } ;
    };



    //COmpound - абстрактный класс на основе котрого строятся все "сложные" , составные классы
    //строки которых заключены между скобками или чемто похожим , (и функции)
    class CompoundStart : public NodeType
    {
    protected :
        //колво операндов которое должно быть у compounda (если равно нулю - то сколькко угодно)
        int operandsneeded= 0;
    public:
        CompoundStart(string symbolset, int operandsneeded) : NodeType(symbolset, 0){
            this->operandsneeded=operandsneeded;
            priority=Priority::High;
            this->symbolset=symbolset;
            followedby[0] = ParserName::UnaryOperation;
            followedby[1] = ParserName::Number;
            followedby[2] = ParserName::CompoundStart;
            followedbycount =3;
           }
        int getoperandsneeded() { return operandsneeded; };
        ParserName name() { return ParserName::CompoundStart; } ;
        double Exec(const double operand[], int operandcount, string str) {
            return operand[0];
        };

        virtual int CanIStartWith(string str)
        {
            //если признак начала Compoundа стоит вначале
            if (str.find(symbolset) == 0)
                return symbolset.length()-1;
            else
                return -1;
        }

    };

    class CompoundEnd : public NodeType
    {
    public:
        CompoundEnd(string symbolset) : NodeType(symbolset, 0){
            priority=Priority::High;
            this->symbolset=symbolset;
            followedby[0] = ParserName::UnaryOperation;
            followedby[1] = ParserName::BinaryOperation;
            followedby[2] = ParserName::CompoundEnd;
            followedby[3] = ParserName::OperandDelimiter;
            followedbycount =4;
           }
        ParserName name() { return anCompoundEnd; } ;
        double Exec(const double operand[], int operandcount, string str) {
            return operand[0];
        };
        virtual int CanIStartWith(string str)
        {
            //если признак начала Compoundа стоит вначале
            if (str.find(symbolset) == 0)
                return symbolset.length()-1;
            else
                return -1;
        }


    };

        //разделитель аргументов в функциях
class OperandDelimiter : public NodeType
{
public:
    OperandDelimiter(string symbolset): NodeType(symbolset, 1)  {
        followedby[0] = ParserName::Number;
        followedby[1] = ParserName::CompoundStart;
        followedby[2] = ParserName::UnaryOperation;
        followedbycount =3;
    };
    ParserName name() { return ParserName::OperandDelimiter;};
};


        // узел содержащий конкретную инфиормацию для вычисления
        //операцию либо число
class Node
{
    string strvalue;
    NodeType* nodetype;
protected:
public:
    Node(NodeType& nodetype, string strvalue) {
        this->nodetype = &nodetype;
        this->strvalue = strvalue;
    }
    string getstrvalue() { return strvalue; };
    int args = 0; // кол-во аргументов (заполняется при вычислении ОПН)
    NodeType* getnodetype() { return nodetype; };
    ParserName nodetypename() { return nodetype->name(); };
    Priority getpriority() { return nodetype->getpriority(); };
};

    /*
     * Классы операций (унарных и бинарных и функции)
     * **********************************************************
     * которые строятся на базе абстрактных классов
     * Парсер калькулятора () работает
     * на уровне абстрактных классов, т.к. информации которые
     * они предоставляют достаточно для разбора.
     * пользователь (программер) может определять свои
     * =классы-операции (наследуя от BinaryOperation, UnaryOperation)
     * =классы-числа (наследуя от Number или Constant или напрямую от NodeType)
     * =классы-функции (наследуя от СompoundStart)
     *
     */

//унарные и бинарные
//*******************************************

class UnaryMinus: public UnaryOperation{
public:
    UnaryMinus() : UnaryOperation ("-",Priority::Low) {
        followedby[0] = ParserName::Number;
        followedby[1] = ParserName::CompoundStart;
        followedby[2] = ParserName::UnaryOperation;
        followedbycount =3;
    };
    double Exec(const double operand[], int operandcount, string str) {
        return ( - operand[0]);
    };
};

class Addition: public BinaryOperation {
public:
    Addition() : BinaryOperation ("+",Priority::Low) {};
    double Exec(const double operand[], int operandcount, string str) {
        double op2= operand[0] + *(operand+1);
        return ( op2 );
    };
};

class Substraction: public BinaryOperation {
public:
    Substraction() : BinaryOperation ("-",Priority::Low) {};
    double Exec(const double operand[], int operandcount, string str) {
        double op2= operand[0] - (*(operand+1));
        return ( op2 );
    };
};


class Multiplication: public BinaryOperation {
public:
    Multiplication() : BinaryOperation ("*",Priority::Middle) {};
    double Exec(const double operand[], int operandcount, string str) {
        double op2= operand[0] * (*(operand+1));
        return ( op2 );
    };
};

class Division: public BinaryOperation {
public:
    Division() : BinaryOperation ("/",Priority::Middle) {};
    double Exec(const double operand[], int operandcount, string str) {
        if (abs(*(operand+1)) < TooSmallNumber)
            throw string ("Division: divider is zero or too small.");
        return  operand[0] / (*(operand+1));
    };
};


class Pow: public BinaryOperation {
public:
    Pow() : BinaryOperation ("^",Priority::High) {};
    double Exec(const double operand[], int operandcount, string str) {
        double op2= pow (operand[0] , *(operand+1));
        return ( op2 );
    };
};

class Factorial: public UnaryOperation {
public:
    Factorial() : UnaryOperation("!",Priority::High) {};
    double Exec(const double operand[], int operandcount, string str) {
        double result = 1;
        for ( int i=1; i<=round(operand[0]); i++) {
            result *= i;
        }
        return result ;
    };
};

/* Классы функций
 * Функция начинается с имени с прилегающей скобкой и заканчиваться закрывающей скобкой.
 * В конструктор передается "имя(" и кол-во аргументов которые принимает функция (если =0 то
 * любое кол-во арументов
 * Функция имеет вид name(p1;p2;...pn)
 * где р[n] - аргумент(ы). Колво аргументов >=1 и
 * ";" - это разделитель аргументов.
 * */

class Pi: public Constant {
public:
    Pi() : Constant ("pi") {};
    double Exec(const double operand[], int operandcount, string str) {
        return 3.1415926535897932384626433832795028841971693;
        }
};


class Sines: public CompoundStart {
public:
    Sines() : CompoundStart("sin(",1) {};
    double Exec(const double operand[], int operandcount, string str) {
        return sin(*(operand));
    };
};

class Cosines: public CompoundStart {
public:
    Cosines() : CompoundStart("cos(",1) {};
    double Exec(const double operand[], int operandcount, string str) {
        return cos(*(operand));
    };
};

class Tangents: public CompoundStart {
public:
    Tangents() : CompoundStart("tan(",1) {};
    double Exec(const double operand[], int operandcount, string str) {
        double csn = cos(*operand);
        if ( abs(csn) < TooSmallNumber )
            throw string("Tangents: function is not defined for this angle.");
        else
            return tan(*(operand));
    };
};


class Cotangents: public CompoundStart {
public:
    Cotangents() : CompoundStart("cotan(",1) {};
    double Exec(const double operand[], int operandcount, string str) {
        double ssn = sin(*operand);
        if ( abs(ssn) < TooSmallNumber )
            throw string("Cotangents: function is not defined for this angle.");
        else
            return cos(*(operand))/ssn;
    };
};

//Logarithmic
//*****************************************************

class Exponent: public Constant {
public:
    Exponent() : Constant ("exp") {};
    double Exec(const double operand[], int operandcount, string str) {
        return 2.7182818284590452353602874713526624977572;
        }
    };


class NaturalLogarithm: public CompoundStart {
public:
    NaturalLogarithm() : CompoundStart("ln(",1) {};
    double Exec(const double operand[], int operandcount, string str) {
        if ( (*operand) < 0 )
            throw string("Logarithm: function is not defined for negatives.");
        else
            return log(*operand);
    };
};

class Logarithm: public CompoundStart {
public:
    Logarithm() : CompoundStart("log(",2) {};
    double Exec(const double operand[], int operandcount, string str) {
        if ( (*operand) < 0 )
            throw string("Logarithm: function is not defined for negatives.");
        else {
            double znam = log(*(operand+1));
            if (znam > TooSmallNumber)
                return log(*operand)/znam;
            else
                throw string("Logarithm: function is not defined for this value.");
        }
    };
};


class Average: public CompoundStart {
public:
    Average() : CompoundStart  ("avg(",0) {};
    double Exec(const double operand[], int operandcount, string str) {
        double sum = 0;
        for ( int i=0; i<operandcount; i++) {
            sum += *(operand+i);
        }
        sum /= operandcount;
        return sum ;
    };
};


class Minimum: public CompoundStart {
public:
    Minimum() : CompoundStart ("min(",0) {};
    double Exec(const double operand[], int operandcount, string str) {
        int i = 0;
        double min = *(operand+i);
        for ( i=1; i<operandcount; i++) {
            if ( *(operand+i) < min) min= (*(operand+i));
        }
        return min ;
    };
};

class Maximum: public CompoundStart {
public:
    Maximum() : CompoundStart("max(",0) {};
    double Exec(const double operand[], int operandcount, string str) {
        double max = *(operand);
        for ( int i=1; i<operandcount; i++) {
            if ( *(operand+i) > max) max= (*(operand+i));
        }
        return max ;
    };
};

class ArithmeticProgression: public CompoundStart {
public:
    ArithmeticProgression() : CompoundStart("aprog(",3) {};
    double Exec(const double operand[], int operandcount, string str) {
        if (*(operand+2) <= 0 )
            throw string("Arithmetic progression: Number of elements cannot be negative or zero.");
        return *(operand+2) * (2* (*operand) + *(operand+1)*(*(operand+2)-1))/2;
    };
};


class GeometricProgression : public CompoundStart {
public:
    GeometricProgression() : CompoundStart("gprog(", 3) {};
    double Exec(const double operand[], int operandcount, string str) {
        if (round(*(operand + 2)) < 0)
            throw string("Geometric progression: Number of elements can't be negative.");
        if (round(*(operand + 2)) == 0 && (*(operand + 1) >= 1))
            throw string("Geometric progression: Common ratio (second operand) must be < 1.");

        double oper3 = round(*(operand + 2));
        if ((*(operand + 1)) == 1) // если это не прогрессия
            return (*operand) * oper3;  //то вернуть колво членов умнож-е на первоый член
        else if ((oper3 == 0) && (*(operand + 1)) < 1) //это убывающая прогр-сия и нужна вся сумма
            return *operand / (1 - *(operand + 1));
        else //обычный случай
            return (*(operand)) * (1 - pow(*(operand + 1), oper3)) / (1 - *(operand + 1));
    };
};


    /* Класс "Калькулятор"
     * 
     *
     *
     *
     *
     *
     * */

NodeType* Calculator::SearchNodeType(string& str, NodeType* prevnodetype, int& pos, RecognizeNodeResult& res)
{
    res = RecognizeNodeResult::No;
    int hypolen = -1;  //"стартовая длина" найденного Node вначале пооиска
    int maxpos = -1;  //перемення куда будет записываться макс знач длины строки
    unsigned int i = 0;
    while (i < nodetypes.size()) {
        maxpos = nodetypes[i]->CanIStartWith(str);
        //maxpos содержит индекс последнего имвола строки str удовлетвор-го NodeType
        if ((maxpos != -1) && (hypolen <= maxpos))
        {   //node type is recognized
            hypolen = maxpos;
            res = RecognizeNodeResult::OK;
            //если опознанному объекту разрешено следовать за предыдущим то ОК
            if (prevnodetype != nullptr) {
                if (prevnodetype->CanBeFollowedBy(nodetypes[i]->name())) {
                    res = RecognizeNodeResult::OKCanFollow;
                    break;
                }
            }
            else {
                res = RecognizeNodeResult::OKCanFollow;
                break;
            }
        }

        i++;
    }
    if (res == RecognizeNodeResult::No) {
        pos = -1;
        return nodetypes[0];
    }
    else {
        pos = +hypolen + 1;
        if (i < nodetypes.size())
            return nodetypes[i];
        else
            return nodetypes[0];
    }
}

void Calculator::AddNodeType(NodeType& nodetype)
{
    nodetypes.push_back(&nodetype);
}


virtual Calculator::~Calculator() {
    int i = vec.size() - 1;
    while (i >= 0) {
        delete vec[i];
        vec.pop_back();
        i--;
    }
    i = nodetypes.size() - 1;
    while (i >= 0) {
        delete nodetypes[i];
        nodetypes.pop_back();
        i--;
    }
}


//в обратную польскую нотацию (ОПЗ)
void Calculator::ToReversePolishNotation(string str) {

    stack<Node*> stack;
    //параметры текущего Node
    NodeType* nodetype = 0;
    Node* node = 0;
    //параметры предыдущего Node
    NodeType* prevnodetype = 0;
    Node* prevnode = 0;
    RecognizeNodeResult sntr;
    int nextpos = 0;
    string foundstr = "";

    //очистить вектор перед новым расчетом
    int i = vec.size() - 1;
    while (i >= 0) {
        delete vec[i];
        vec.pop_back();
        i--;
    }

    while (str.length()) {

        //опознать следующий кусок строки
        nodetype = SearchNodeType(str, prevnodetype, nextpos, sntr);
        //если не опознано то ошибка

        switch (sntr) {
        case RecognizeNodeResult::No:
            throw string("Parsing error: unknown symbols starting with " +
                str.substr(0, 3) + "...'");
            break;
        case RecognizeNodeResult::OK:
            foundstr = str.substr(0, nextpos);
            throw string("Parsing error: " + prevnode->getstrvalue() +
                " can't be followed by " + foundstr + ".");  //node->getstrvalue()
            break;
        case RecognizeNodeResult::OKCanFollow:
            foundstr = str.substr(0, nextpos);
            node = new Node(*nodetype, foundstr);
            break;
        }

        //В зависимости от ТИПА КИДА разные сценарии
        switch (nodetype->name()) {

        case ParserName::Number:
            vec.push_back(node);
            break;
        case ParserName::UnaryOperation:
            stack.push(node);
            break;
        case ParserName::BinaryOperation:
            while (!stack.empty() && (stack.top()->nodetypename() == anBinaryOperation ||
                stack.top()->nodetypename() == anUnaryOperation)) {
                if (stack.top()->getpriority() >= (nodetype)->getpriority()) {
                    vec.push_back(stack.top());
                    stack.pop();
                }
                else
                    break;
            }
            stack.push(node);
            break;

        case ParserName::CompoundStart:
            stack.push(node);
            break;
        case ParserName::CompoundEnd: {
            int counter = 1;
            while ((!stack.empty() && (stack.top()->nodetypename() != anCompoundStart)))
            {
                if (stack.top()->nodetypename() == ParserName::OperandDelimiter) {
                    counter++;
                }
                else vec.push_back(stack.top());

                stack.pop();
            };
            //должны уже добраться до начало сcompounda (в этой точке)
            if (stack.empty())
                throw string("Parsing error: missed open bracket or function name.");
            else
            {// если (stack.top()->nodetypename() == anCompoundStart ) {
                if (counter > MAXOPERANDCOUNT) throw string("Too many operands.");
                stack.top()->args = counter;
                vec.push_back(stack.top());
                stack.pop();
            }
            break;
        }


        case ParserName::OperandDelimiter:
            //если предыдущий аргумент Compounda сложный то перед тем как положить делимитер в стек нужно
            //вытащить в vector все операции относящиеся к предыд аргументу
            while (!stack.empty() && (stack.top()->nodetypename() == anBinaryOperation ||
                (stack.top()->nodetypename() == anUnaryOperation)))
            {
                vec.push_back(stack.top());
                stack.pop();
            }
            //Если стек пуст значит встретился делимитер без compounda
            if (stack.empty())
                throw string("Parsing error: " + nodetype->getsymbolset() + " w/o function name.");
            stack.push(node);
            break;

        default:
            throw string("Unknown parsing error.");
            break;
        }

        str = str.substr(nextpos, str.length() - nextpos);
        prevnodetype = nodetype;
        prevnode = node;
    }

    //записать оставшееся в стеке в вектор
    while (!stack.empty()) {
        if (stack.top()->nodetypename() == ParserName::CompoundStart) { // && !stack.top()->args) {
            throw string("Parsing error: missed close bracket.");
        }
        vec.push_back(stack.top());
        stack.pop();
    }

}


//Вычисление ОПЗ (Обратной польской нотации)
double Calculator::Execute()
{
    stack<double> stack;

    unsigned int v = 0;
    while (v < vec.size())
    {
        double operands[MAXOPERANDCOUNT];
        NodeType* nodetype = vec[v]->getnodetype();
        switch (vec[v]->nodetypename()) {

        case ParserName::Number:
            //посчитать число (из строки в double) и положить его в стек
            stack.push(nodetype->Exec(nullptr, 1, vec[v]->getstrvalue()));
            break;

        case ParserName::UnaryOperation:
            if (stack.size() >= 1) {
                operands[0] = stack.top(); stack.pop();
                stack.push(nodetype->Exec(operands, 1, ""));
                break;
            }
            else
                throw string("Parsing error: must be 1 operand for " +
                    dynamic_cast<UnaryOperation*>(nodetype)->getsymbolset() +
                    " operation.");

        case ParserName::BinaryOperation:
            if (stack.size() >= 2) {
                operands[1] = stack.top(); stack.pop();
                operands[0] = stack.top(); stack.pop();
                stack.push(nodetype->Exec(operands, 2, ""));
                break;
            }
            else
                throw string("Parsing error: must be 2 operands for " +
                    dynamic_cast<BinaryOperation*>(nodetype)->getsymbolset() +
                    " operation.");

        case ParserName::CompoundStart: {
            //проверить совпадает ли кол-во операндов необходимое Compound и тому что записано
            int i = dynamic_cast<CompoundStart*>(nodetype)->getoperandsneeded();
            if (i != 0 && vec[v]->args != i)
                throw string("Parsing error: operand count mismatch.");
            //выбраь операнды из стека
            i = vec[v]->args - 1;
            while (i >= 0 && !stack.empty() && i < MAXOPERANDCOUNT) {
                operands[i] = stack.top();
                stack.pop();
                i--;
            }
            if (stack.empty() && i != -1)
                throw string("Parsing error: Not enough operands.");
            //посчитать Результат Compounda и положить его в стек
            stack.push(nodetype->Exec(operands, vec[v]->args, ""));
            break;
        }
        default:
            throw string("Error in parsing procedure.");
            break;

        }
        v++;
    }

    if (!stack.empty())
        return stack.top();
    else
        throw string("Unknown parsing error.");
};
   

