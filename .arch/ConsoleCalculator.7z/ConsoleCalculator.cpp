﻿
#include <iostream>
#include <Calculator.h>

Calculator Calc;

bool Init()
{
    Calc = new Calculator;
    Calc->AddNodeType(*new Number());
    Calc->AddNodeType(*new CompoundEnd(")"));
    Calc->AddNodeType(*new CompoundStart("(", 0));
    Calc->AddNodeType(*new OperandDelimiter(";"));
    Calc->AddNodeType(*new UnaryMinus());
    Calc->AddNodeType(*new Addition());
    Calc->AddNodeType(*new Substraction());
    Calc->AddNodeType(*new Multiplication());
    Calc->AddNodeType(*new Division());
    Calc->AddNodeType(*new Pow());
    Calc->AddNodeType(*new Factorial());
    Calc->AddNodeType(*new Pi());
    Calc->AddNodeType(*new Sines());
    Calc->AddNodeType(*new Cosines());
    Calc->AddNodeType(*new Tangents());
    Calc->AddNodeType(*new Cotangents());
    Calc->AddNodeType(*new Exponent());
    Calc->AddNodeType(*new Logarithm());
    Calc->AddNodeType(*new NaturalLogarithm());
    Calc->AddNodeType(*new Average());
    Calc->AddNodeType(*new Minimum());
    Calc->AddNodeType(*new Maximum());
    Calc->AddNodeType(*new ArithmeticProgression());
    Calc->AddNodeType(*new GeometricProgression());





}

int main()
{



}

