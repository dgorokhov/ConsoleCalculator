﻿
#include <iostream>
#include <memory>
#include "Calculator.h"


void DelSpaceSymbols(string& s) {
    static char todel[] = { ' ','\n','\r','\v','\f','\t' };
    string::size_type pos = string::npos;
    for (char i : todel) {
        pos = s.find(i);
        while (pos != string::npos) {
            s.erase(pos, 1);
            pos = s.find(i);
        }
    }
};

const Calculator& Init()
{
    auto Calc = new Calculator();
    Calc->AddNodeType(*new Number());
    Calc->AddNodeType(*new CompoundEnd(")"));
    Calc->AddNodeType(*new CompoundStart("(", 0));
    Calc->AddNodeType(*new OperandDelimiter(";"));
    Calc->AddNodeType(*new UnaryMinus());
    Calc->AddNodeType(*new Addition());
    Calc->AddNodeType(*new Substraction());
    Calc->AddNodeType(*new Multiplication());
    Calc->AddNodeType(*new Division());
    Calc->AddNodeType(*new Pow());
    Calc->AddNodeType(*new Factorial());
    Calc->AddNodeType(*new Pi());
    Calc->AddNodeType(*new Sines());
    Calc->AddNodeType(*new Cosines());
    Calc->AddNodeType(*new Tangents());
    Calc->AddNodeType(*new Cotangents());
    Calc->AddNodeType(*new Exponent());
    Calc->AddNodeType(*new Logarithm());
    Calc->AddNodeType(*new NaturalLogarithm());
    Calc->AddNodeType(*new Average());
    Calc->AddNodeType(*new Minimum());
    Calc->AddNodeType(*new Maximum());
    Calc->AddNodeType(*new ArithmeticProgression());
    Calc->AddNodeType(*new GeometricProgression());

    cout << "\nConsole *** Kiss the Pig *** Calculator\n"
         <<"----------------------------------------\n"
        << "Arithmetic: + - / * ^ \n"
        << "Functions: !number sin() cos() tan() cotan() log() ln() \n"
        << "Constants: pi exp \n"
        << "Special: \n"
        << "  max(n1,...nN) - selects maximum of numbers from n1 to nN\n"
        << "  min(n1,...nN) - selects minimum of numbers from n1 to nN\n"
        << "  avg(n1,...nN) - calculates the average of numbers from n1 to nN\n"
        << "  aprog(base; ratio; number_of_elements) - sum of arithmetic progression\n"
        << "  gprog(base; ratio; number_of_elements) - sum of geometric progression\n\n"
        << "Operands inside function calls must be delimited by ;\n"
        << "You can build complex expressions like: \n\n"
        << "   ((2.2212+3*-10) * max(10; 33+2^avg(12; ln(11); 5*6.23; 3^7); 11)) / (13 * 12)\n\n";

    return *Calc;
}

static const char* prompt = "KissThePig > ";


int main()
{
    auto calc = make_unique<Calculator>(Init());
    string rpn;
   
    while (true) {
        try {
            cout << prompt;
            getline(std::cin, rpn);
            DelSpaceSymbols(rpn);
            if (rpn == "exit" || rpn == "quit") return 0;
            //cout << rpn << endl;
            calc->ToReversePolishNotation(rpn);
            cout << calc->Execute() << endl;
        }
        catch (string s)
        {
            cout << "   " << s << endl;
        }
        catch (...) 
        {
           cout << "   " << "Unknown error. Try again.\n";
        }
        
    }
}

