    ================================
        Help from Masha the pig 
    ================================


CONTENTS
--------------------------------------
1. For Users
2. For Developers (in Russian)
--------------------------------------

1. For Users
--------------------------------------
You can use binary operations 
 *, +, -, /, ^ (pow) with any other functions below. 

Logarithmic:
  LN(), LOG(what, base)
  EXP - 2.71...

Trigonometric:
  SIN(), COS(), TAN(), COTAN()
  PI - 3.14...

Other:
  !num - factorial of num
  MIN(...), MAX(...), AVG(...) - with any number of operands
  APROG(base; ratio; number_of_elements) - sum of arithmetic progression 
  GPROG(base; ratio; number_of_elements) - sum of geometric progression 

Operands inside function calls must be delimited by ;

You can build complex expressions like:
  ((2+3*-10)^max(10;33+2^avg(12;ln(11);5*6;3^7);11))/(13*12));


2. For Developers
--------------------------------------
Calculator can be easily extended. New functions can be added in minutes.
Learn Russian and read comments in source files!

Masha wish you good luck! Khrou-khrou wee-wee-wee
if you want to teach Masha new calculating mail to:dgorohov@mail.ru
After taking mud shower and a cup of coffee Masha will see what she can do.
